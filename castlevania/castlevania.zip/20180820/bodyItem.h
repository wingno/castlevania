#pragma once
#include "item.h"
class bodyItem :
	public item
{
public:
	bodyItem();
	~bodyItem();
};

