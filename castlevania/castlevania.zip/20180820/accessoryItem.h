#pragma once
#include "item.h"
class accessoryItem :
	public item
{
public:
	accessoryItem();
	~accessoryItem();
};

