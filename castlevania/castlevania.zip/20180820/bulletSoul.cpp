#include "stdafx.h"
#include "bulletSoul.h"


void bulletSoul::init(int cType, int cCount, int cIdx, int cAtt, int cDef, int cStr, int cInt, int cCon, int cLuc, int cHp, int cMp, string cName, string cExplanation)
{
	soul::init(cType, cCount, cIdx, cAtt, cDef, cStr, cInt, cCon, cLuc, cHp, cMp, cName, cExplanation);



}

void bulletSoul::release()
{
}

void bulletSoul::update()
{
}

void bulletSoul::render()
{
}

bulletSoul::bulletSoul()
{
}


bulletSoul::~bulletSoul()
{
}
