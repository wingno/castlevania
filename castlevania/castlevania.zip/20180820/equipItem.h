#pragma once
#include "item.h"
class equipItem :
	public item
{
public:
	equipItem();
	~equipItem();
};

