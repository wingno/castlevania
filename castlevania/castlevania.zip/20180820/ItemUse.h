#pragma once
#include "item.h"
class ItemUse :public item
{
public:
	ItemUse();
	~ItemUse();
};

