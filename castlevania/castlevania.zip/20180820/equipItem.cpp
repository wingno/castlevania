#include "stdafx.h"
#include "equipItem.h"


equipItem::equipItem()
{
}


equipItem::~equipItem()
{
}
