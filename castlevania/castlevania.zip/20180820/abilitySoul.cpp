#include "stdafx.h"
#include "abilitySoul.h"


void abilitySoul::init(int cType, int cCount, int cIdx, int cAtt, int cDef, int cStr, int cInt, int cCon, int cLuc, int cHp, int cMp, string cName, string cExplanation)
{
	soul::init(cType, cCount, cIdx, cAtt, cDef, cStr, cInt, cCon, cLuc, cHp, cMp, cName, cExplanation);
}

void abilitySoul::release()
{
}

void abilitySoul::update()
{
}

void abilitySoul::render()
{
}

abilitySoul::abilitySoul()
{
}


abilitySoul::~abilitySoul()
{
}
