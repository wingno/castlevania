#include "stdafx.h"
#include "guardianSoul.h"


void guardianSoul::init(int cType, int cCount, int cIdx, int cAtt, int cDef, int cStr, int cInt, int cCon, int cLuc, int cHp, int cMp, string cName, string cExplanation)
{
	soul::init(cType, cCount, cIdx, cAtt, cDef, cStr, cInt, cCon, cLuc, cHp, cMp, cName, cExplanation);

}

void guardianSoul::release()
{
}

void guardianSoul::update()
{
}

void guardianSoul::render()
{
}

guardianSoul::guardianSoul()
{
}


guardianSoul::~guardianSoul()
{
}
