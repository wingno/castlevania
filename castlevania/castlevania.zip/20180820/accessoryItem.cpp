#include "stdafx.h"
#include "accessoryItem.h"


accessoryItem::accessoryItem()
{
}


accessoryItem::~accessoryItem()
{
}
