#include "stdafx.h"
#include "bodyItem.h"


bodyItem::bodyItem()
{
}


bodyItem::~bodyItem()
{
}
