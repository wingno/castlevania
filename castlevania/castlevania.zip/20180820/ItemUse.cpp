#include "stdafx.h"
#include "ItemUse.h"


ItemUse::ItemUse()
{
}


ItemUse::~ItemUse()
{
}
