#pragma once
class castleMap
{
public:
	castleMap();
	~castleMap();
};

