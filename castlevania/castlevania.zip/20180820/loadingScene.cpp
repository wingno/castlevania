#include "stdafx.h"
#include "loadingScene.h"


HRESULT loadingScene::init()
{



	return S_OK;
}

void loadingScene::release()
{
}

void loadingScene::update()
{




}

void loadingScene::render(HDC hdc)
{

}

loadingScene::loadingScene()
{
}


loadingScene::~loadingScene()
{
}
