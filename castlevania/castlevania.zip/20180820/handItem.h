#pragma once
#include "item.h"
class handItem :
	public item
{
public:
	handItem();
	~handItem();
};

