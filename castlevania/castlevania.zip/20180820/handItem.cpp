#include "stdafx.h"
#include "handItem.h"


handItem::handItem()
{
}


handItem::~handItem()
{
}
